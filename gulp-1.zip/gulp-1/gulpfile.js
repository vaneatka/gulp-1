const gulp = require('gulp');
const concatCss = require('gulp-concat-css')
const uglify = require('gulp-uglify');
const postcss = require('gulp-postcss');
const autoprefixer = require('autoprefixer');
const csslint = require('gulp-csslint');
const cleanCss = require('gulp-clean-css');
const rename = require('gulp-rename');

// TASK -CSS post process

exports.css = (cb) =>{
    // concatenation

    // uglify

    // post css / autoprefixer
    let config_browsers = {
        browsers: [
            '>1% in MD',                // toate browserele cu +1% in md
            'last 10 versions',         // ultimele 10 versiuni
            'Firefox ESR',
            'not ie <10'
        ]

    }

    return gulp
        .src('./src/css/*.css')                                                         //.src  citim din sursa
            .pipe(csslint())                                                        // verifica cssul
            .pipe(csslint.formatter())                                                 // coding style
            .pipe(postcss([autoprefixer(config_browsers)]) )                          // postcss
            //.pipe(uglify())                                                            //concat si minim
            .pipe(concatCss('style.css'))                                           // concatenare
            .pipe(gulp.dest('./dist/css'))
            .pipe(cleanCss())
            .pipe(rename('style.min.css'))
            .pipe(gulp.dest('./dist/css'))                                          // .dist le plasam la destinatie
            ;
}





// // default task
// exports.default = (cb) =>{
//     console.log('starting default task!!!');
//     cb();    
// }



//  1) task scss *scss -> *.css
//  2)  task script *.js -> concat \/ uglify -> js
            // es6 -> transpilat .> es5 old js